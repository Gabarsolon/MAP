package Model.Exceptions;

public class MyException extends Exception{
    public MyException(String error){
        super(error);
    }
}
