package Model.States;

import java.util.List;

public interface MyIList<T>{
    public void add(T elem);
    public List<T> getData();
}
